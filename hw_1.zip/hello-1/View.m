//
//  View.m
//  hello
//
//  Created by shasha on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"


@implementation View


- (id)initWithFrame:(CGRect)frame {
    
   
    if ((self =  self = [super initWithFrame:frame])!= nil) {
        // Initialization code.
		//self.backgroundColor = [UIColor yellowColor];
		self.backgroundColor = [UIColor colorWithRed: 0.0 green: 0.74902 blue: 1.0 alpha: 1.0];
    }
    return self;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
	
	//dimensions
	NSLog(@"self.frame == (%g, %g), %g × %g",
		  self.frame.origin.x,
		  self.frame.origin.y,
		  self.frame.size.width,
		  self.frame.size.height
		  );
	
	NSLog(@"self.bounds == (%g, %g), %g × %g",
		  self.bounds.origin.x,
		  self.bounds.origin.y,
		  self.bounds.size.width,
		  self.bounds.size.height
		  );
	
    // Drawing code
	UIFont *f = [UIFont systemFontOfSize: 32.0];
   //[@"origin" drawAtPoint: CGPointZero withFont: f];
	NSString *s = NSLocalizedString(@"Greeting", @"displayed with drawAtPoint:");

	// Drawing shape code
	CGRect b = self.bounds;
	CGFloat radius = .3 * b.size.width;	//in pixels
	
	CGPoint p = CGPointMake((b.size.width)/4, (b.size.height)/2);
	[s drawAtPoint:p withFont: f];
	
	
	
	/*
	 Create the invisible square that will surround the circle.
	 Place the upper left corner of the square at the upper left corner of
	 the View.  b.origin.x and b.origin.y are the coordinates of the upper
	 left corner of the View.
	
	CGRect r = CGRectMake(
						  b.origin.x,
						  b.origin.y,
						  1 * radius,
						  2 * radius
						  );
	*/
	CGRect r = CGRectMake(
						  -radius,
						  -radius,
						  2 * radius,
						  2 * radius
						  );
	
	CGContextRef c = UIGraphicsGetCurrentContext();
	CGContextTranslateCTM(c, b.size.width / 2, b.size.height / 2);
	CGContextBeginPath(c); //unnecessary here: the path is already empty.
	CGContextAddEllipseInRect(c, r);
	CGContextSetRGBFillColor(c, 0.5, 0.5, 0.0, 0.5);	//color
	CGContextFillPath(c);
	
	
}


- (void)dealloc {
    [super dealloc];
}


@end
