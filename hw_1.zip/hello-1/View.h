//
//  View.h
//  hello
//
//  Created by shasha on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {

}

@end
