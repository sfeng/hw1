//
//  Shape.h
//  hello
//
//  Created by Sha Sha on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface ShapeAppDelegate: NSObject <UIApplicationDelegate> {
	View *view;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@end
